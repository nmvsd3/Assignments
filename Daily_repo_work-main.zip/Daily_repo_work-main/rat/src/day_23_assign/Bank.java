package day_23_assign;

public class Bank {

	int getRateOfInterest() {
		return 0;
	}
}

