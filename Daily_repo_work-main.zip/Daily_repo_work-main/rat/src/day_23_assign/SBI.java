package day_23_assign;

public class SBI extends Bank{

	

		int getRateOfInterest(){
		return 8;
		}
		}

