package day_23_assign;

public class AXIS extends Bank{

	
	
		int getRateOfInterest(){
		return 9;
		}
}
