package com.practice;

import java.util.Scanner;

// print the total length of array

//public class Ant_1 {
//
//	public static void main(String[] args) {
//		
//		String[] arr= {"dsffdfdf","sdfdf","dsfgrg","drwfs","wfewf","fewfer"};
//		System.out.println("total array Length : "+arr.length);
//	}
//
//}


//find ‘pvt’ exist in this string or not

//public class Ant_1{
//	
//	public static void main(String[] args) {
//		String des="super man on the way to the office pvt";
//		System.out.println(des.contains(des));
//	}
//}


//find the substring starting form index 7

//public class Ant_1{
//	public static void main(String[] args) {
//		String ind="tata birla";
//		System.out.println(ind.charAt(7));
//	}
//}


//find the substring staring from index 3 to index 13

//public class Ant_1{
//	public static void main(String[] args) {
//		String s="tata birla madhya lo laila";
//		System.out.println(s.substring(3, 13));
//	}
//}

//public class Ant_1{
//	public static void main(String[] args) {
//		String str1="The original string is there in ";
//		String str2=str1+"SR Nagar hyderabad";
//		System.out.println(str2);
//	}
//}

public class Ant_1{
//	String s="vasuchinna";
//	public  boolean isPalindrome(String s) {
//  
//        s = s.replaceAll("[^A-Za-z0-9]", "").toLowerCase();
//        int left = 0, right = s.length() - 1;
//        while (left < right) {
//            if (s.charAt(left) != s.charAt(right)) {
//                return false;
//            }
//            left++;
//            right--;
//        }
//        return true;
//    }
	
}






















