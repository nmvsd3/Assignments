package day_21_assign;

public class CompareIntegers {
    public static void main(String[] args) {
    	
    	
//        int num1 = 10;
//        int num2 = 20;
//
//        if (num1 == num2) {
//            System.out.println("The two integers are equal.");
//        } else {
//            System.out.println("The two integers are not equal.");
//        }
    	
    	
//    	String str = "Sunita";
//    	String str1 = "Sunita";
//
//    	boolean result = (str == str1);
//    	boolean result1 = str.equals(str1);
//
//    	System.out.println("Using == operator: " + result);
//    	System.out.println("Using equals() method: " + result1);

    	
    	
    	//string is mutable example
    	
//    	StringBuilder sb = new StringBuilder("Hello");
//    	sb.append(" World");
//    	sb.insert(5, " Java");
//    	sb.delete(11, 16);
//    	String result = sb.toString();
//    	System.out.println(result); 

    	
    }
}
